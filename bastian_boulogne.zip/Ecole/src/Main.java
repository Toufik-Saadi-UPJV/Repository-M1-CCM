import java.util.Date;

public class Main {
    public static void main(String args[]) {
        Tache tache1 = new Tache("Alex est recruté", 1, new Date(2020, 5, 10));
        Tache tache2 = new Tache("Alex travaille", 2, new Date(2021, 9, 20));
        Tache tache3 = new Tache("Alex est viré", 3, new Date(2022, 9, 25));

        Agenda agenda = new Agenda();
        agenda.ajouterTache(tache1);
        agenda.ajouterTache(tache2);
        agenda.ajouterTache(tache3);

        Employe employe1 = new Employe(agenda);
        // Décocher pour voir avec deux threads
        //Employe employe2 = new Employe(agenda);

        try {
            employe1.start();
            // Décocher pour voir avec deux threads
            //employe2.start();

            employe1.join();
            // Décocher pour voir avec deux threads
            //employe2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Fin du programme");
    }
}
