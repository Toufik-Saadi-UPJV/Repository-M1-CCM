/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package S3;

/**
 *
 * @author Samy
 */
public class Main {
    public static void main(String[] args) {
        //region partie 1
        /*
        Task threadCTask = new Task("c");
        Thread threadC = new Thread(threadCTask);;
        Thread threadB = new Thread(new Task("b", threadC));
        Thread threadA = new Thread(new Task("a", threadB));
        Thread threadD = new Thread(new Task("d", threadA));
        threadCTask.setPreviousThread(threadD);

        threadC.start();
        threadB.start();
        threadA.start();
        threadD.start();*/
        //endregion
        
        //region  partie 2
        int iterate = 0;
        try {
            iterate = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            System.out.println(e.getMessage());
            System.exit(-1);
        }

        Thread previous = null;
        for(int i = 0 ; i < iterate; i++) {
            Thread thread = new Thread(new Task(Integer.toString(i), previous));
            previous = thread;
            thread.start();
        }
        //endregion

    }

}
