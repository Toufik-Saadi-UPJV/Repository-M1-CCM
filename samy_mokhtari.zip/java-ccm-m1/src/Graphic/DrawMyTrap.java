/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Graphic;

import Pixel.Pixel;
import static Pixel.Pixel.same;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Samy
 */
public class DrawMyTrap extends JPanel {
    Pixel[] pixels;
    
    public DrawMyTrap(Pixel[] p_Pixels) {
        pixels = p_Pixels;
    }
    
    public void paint(Graphics g){
        if(pixels == null) throw new IllegalArgumentException();
        
        int pixelCount = pixels.length;
        
        g.drawLine(0, 0, (int)pixels[0].getX(), (int)pixels[0].getY());
        for(int index = 0; index < pixelCount-1 ; index++) {
            g.drawLine((int)pixels[index].getX(), (int)pixels[index].getY(), (int)pixels[index+1].getX(), (int)pixels[index+1].getY());
        }
        g.drawLine((int)pixels[pixelCount-1].getX(), (int)pixels[pixelCount-1].getY(), 0, 0);
        /* Diagonales */
        int counter = 0;
         for(int index = 0; index < pixelCount-1 ; index++) {
            g.drawLine((int)pixels[pixelCount/2].getX(), (int)pixels[pixelCount/2].getY(), 0, 0);
         }
    }
  
    public static void main(String[] args){
        JFrame f = new JFrame("Dessiner un trapèze");
        Pixel p0 = new Pixel(0,0);
        Pixel p1 = new Pixel(10,30);
        Pixel p2 = new Pixel(40,30);
        Pixel p3 = new Pixel(30,0);
        f.getContentPane().add(new DrawMyTrap(new Pixel[] { p0, p1, p2 , p3 }));
        f.setSize(450, 450);
        f.setVisible(true);
        f.setResizable(false);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
