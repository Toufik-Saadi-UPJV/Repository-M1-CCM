/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

/**
 *
 * @author Samy
 */
public class Employee {
    private Agenda agenda;    
    private String name;

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }


    public Employee(Agenda agenda, String name) {
        setAgenda(agenda);
        setName(name);
    }

    public Employee() {
        setAgenda(new Agenda());
    }

    public Agenda getAgenda() {
        return agenda;
    }

    public void setAgenda(Agenda agenda) {
        this.agenda = agenda;
    }

    @Override
    public String toString() {
        return "Name : " + getName() + " | Tasks : \n" + getAgenda().tasks.toString();
    }
    
}
