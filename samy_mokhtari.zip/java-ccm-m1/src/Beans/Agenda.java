/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import static java.util.stream.Collectors.toCollection;

/**
 *
 * @author Samy
 */
public class Agenda {
    ArrayList<MyTask> tasks;

    public Agenda() {
        setTasks(new ArrayList());
    }
    
    public Agenda(ArrayList<MyTask> tasks) {
        setTasks(tasks);
    }
    
    public ArrayList<MyTask> getTasksCompleted() {
        return tasks.stream().filter(c -> !c.isFinished()).collect(toCollection(ArrayList::new));
    }
    
    public ArrayList<MyTask> getTaskForDate(Date date) {
        return tasks.stream().filter(task -> task.getStart().equals(date)).collect(toCollection(ArrayList::new));
    }

    public ArrayList<MyTask> getTasks() {
        Comparator<MyTask> taskComparator = (t1, t2) -> t1.getStart().compareTo(t2.getStart());
        return tasks.stream().sorted(taskComparator).collect(toCollection(ArrayList::new));
    }

    public void setTasks(ArrayList<MyTask> tasks) {
        this.tasks = tasks;
    }
    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        for(MyTask t : tasks){
            result.append(t.toString());
        }
        return result.toString();
    }
}
