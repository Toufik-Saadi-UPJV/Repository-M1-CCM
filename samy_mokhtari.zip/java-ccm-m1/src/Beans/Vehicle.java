/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import java.awt.Color;
import java.beans.*;

/**
 *
 * @author Samy
 */
public class Vehicle {

    private int horsepower;
    private Color color;
    
    public Vehicle() {
        color = Color.WHITE;
        horsepower = 0;
        this.addPropertyChangeListener( 
            new PropertyChangeListener() {
                @Override
                public void propertyChange(PropertyChangeEvent event) {
                    System.out.println("PropertyChangeEvent -> Changement de valeur: " + event.getNewValue());
                }
            }
        );
    }

    
    private void addPropertyChangeListener(PropertyChangeListener propertyChangeListener) {
        
    }
    
    
    /* Accesseurs */
    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public int getHorsepower() {
        return horsepower;
    }

    public void setHorsepower(int horsepower) {
        this.horsepower = horsepower;
    }
    
    
}
