/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tasks2;

import static java.lang.Thread.sleep;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Jeremy KRZ
 */
public class Tache implements Runnable{
    private String libelle;
    private int priorite;
    private LocalDateTime date;
    private boolean effectuee;
    private Thread predecesseur;
    
    public Tache(String lib, int prio, LocalDateTime date){
        this.libelle = lib;
        this.priorite = prio;
        this.date = date;
        this.effectuee = false;
    }
    
    public Tache(String lib){
        this.libelle = lib;
        this.priorite = 1;
        this.date = LocalDateTime.now();
        this.effectuee = false;
    }
    
    public Tache(String lib, ArrayList<Thread> ListT){
        this.libelle = lib;
        this.priorite = 1;
        this.date = LocalDateTime.now();
        this.effectuee = false;
        setPredecesseur(ListT.get(0));
    }
    
    public void Affiche_tache(){
        System.out.println("Libelle : "+this.libelle + "\nPriorité : "+this.priorite
                +"\nDate : " + this.date.toString() + "\nEffectuee : " + String.valueOf(this.effectuee));
    }
    
    public String getLibelle(){
        return this.libelle;
    }
    public boolean isEffectuee(){
        return this.effectuee;
    }
    
    public LocalDateTime getDate(){
        return this.date;
    }
    
    public int getPriorite(){
        return this.priorite;
    }
    
    public void setLibelle(String libelle){
        this.libelle = libelle;
    }
    public void setPriorite(int priorite){
        this.priorite = priorite;
    }
    public void setEffectuee(boolean effectuee){
        this.effectuee = effectuee;
    }
    public void setDate(LocalDateTime date){
        this.date = date;
    }
    public final void setPredecesseur(Thread T){
        predecesseur = T;
    }

    @Override
    public void run() {
        try{
            if(predecesseur != null){
                predecesseur.join();
            }
            System.out.println("Tache en Action : " +this.libelle);
            sleep(3000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Tache.class.getName()).log(Level.SEVERE, null, ex);
        }
    }  
}
