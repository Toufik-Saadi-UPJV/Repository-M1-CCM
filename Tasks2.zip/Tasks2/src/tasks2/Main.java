/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tasks2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Jeremy KRZ
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /* Tache tache1 = new Tache("tache1",1,LocalDateTime.now());
        Tache tache2 = new Tache("tache2",2,LocalDateTime.now());
        Tache tache3 = new Tache("tache3",3,LocalDateTime.now());
        
        tache3.Affiche_tache();
        ArrayList<Tache> taches = new ArrayList<>();
        taches.add(tache1);
        taches.add(tache2);
        
        Agenda agenda1 = new Agenda(taches);
        
        Employe employe1 = new Employe(agenda1);
        
        try{
            employe1.start();
            
            employe1.join();
        }catch(InterruptedException ex){
        }
        
        System.out.println("\n------------Terminer--------------------");*/
        
       /*Tache tacheC = new Tache("tache C");
        Thread TC = new Thread(tacheC,"TC");
        Thread TB = new Thread(new Tache("tache B",new ArrayList<>(Arrays.asList(TC))),"TB");
        Thread TA = new Thread(new Tache("tache A",new ArrayList<>(Arrays.asList(TB))),"TA");
        Thread TD = new Thread(new Tache("tache D",new ArrayList<>(Arrays.asList(TA))),"TD");
        //tacheC.setPredecesseur(TD);
        
        TA.start();
        TC.start();
        TB.start();
        //TD.start();*/
        
        int n=Integer.parseInt(args[0]);
        List<Thread> threads = new ArrayList<Thread>();
        for(int i=n; i>0;i--){
            String name = "T" + String.valueOf(i);
            if(i==n){
                threads.add(new Thread(new Tache(name),name));
            }else{
                threads.add(
                        new Thread(new Tache(name,new ArrayList<>(Arrays.asList(threads.get(n-i-1)))),name));
            }
        }
        threads.forEach(T -> T.start());
    }
}
